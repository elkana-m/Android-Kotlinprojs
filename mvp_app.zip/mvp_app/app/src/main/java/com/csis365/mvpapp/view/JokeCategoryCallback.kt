package com.csis365.mvpapp.view

interface JokeCategoryCallback {
    fun onCategorySelected(category: String)
}