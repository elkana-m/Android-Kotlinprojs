package com.csis365.mvpapp.dto

data class Fruit(
    val id: Int?,
    val name: String?,
    val genus: String?,
    val family: String?,
    val order: String?,
    val nutritions: Nutrition?
)