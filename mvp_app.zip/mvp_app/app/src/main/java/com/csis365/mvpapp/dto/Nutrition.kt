package com.csis365.mvpapp.dto

data class Nutrition(
    val carbohydrates: Double?,
    val protein: Double?,
    val fat: Double?,
    val calories: Double?,
    val sugar: Double?,
)